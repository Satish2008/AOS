        //   Q.1
a=4
b=5
document.write(++a,b++)